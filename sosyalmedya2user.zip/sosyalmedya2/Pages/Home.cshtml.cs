using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Antiforgery;

// Burada tüm namespace'leri tam olarak belirtelim
using sosyalmedya2.Models;
using sosyalmedya2.Services;
using sosyalmedya2.Data;

#pragma warning disable CS1061 // Type does not contain definition
#pragma warning disable CS0246 // Type or namespace not found
#pragma warning disable CS0103 // Name does not exist in current context

namespace sosyalmedya2.Pages
{
    [IgnoreAntiforgeryToken(Order = 1001)]
    public class HomeModel : PageModel
    {
        private readonly ILogger<HomeModel> _logger;
        private readonly NewsService _newsService;
        private readonly UserService _userService;
        private readonly NewsDbContext _newsDbContext;
        private readonly UserDbContext _userDbContext;

        public List<News> NewsList { get; set; } = new List<News>();
        public int? CurrentUserId { get; set; }
        public User? CurrentUser { get; set; }

        [TempData]
        public string? StatusMessage { get; set; }

        public HomeModel(ILogger<HomeModel> logger, NewsService newsService, UserService userService,
                        NewsDbContext newsDbContext, UserDbContext userDbContext)
        {
            _logger = logger;
            _newsService = newsService;
            _userService = userService;
            _newsDbContext = newsDbContext;
            _userDbContext = userDbContext;
        }

        public async Task OnGetAsync()
        {
            _logger.LogInformation("Home page visited at: {time}", DateTime.Now);

            try
            {
                // Haberleri yalnızca NewsService üzerinden al
                try
                {
                    _logger.LogInformation("Haberleri getirmek için NewsService.GetAllNewsAsync çağrılıyor...");
                    NewsList = await _newsService.GetAllNewsAsync();
                    _logger.LogInformation("NewsService'ten {count} haber alındı", NewsList.Count);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Haberleri getirirken bir hata oluştu");
                    StatusMessage = "Haberler yüklenirken bir hata oluştu. Lütfen sayfayı yenileyin.";
                }

                // Kullanıcı oturum açmış mı kontrol et
                byte[]? userIdBytes = null;
                if (HttpContext.Session.TryGetValue("UserId", out userIdBytes) && userIdBytes != null)
                {
                    CurrentUserId = BitConverter.ToInt32(userIdBytes, 0);
                    CurrentUser = await _userService.GetUserByIdAsync(CurrentUserId.Value);
                    _logger.LogInformation("Kullanıcı giriş yapmış: {userId}, {username}", CurrentUserId, CurrentUser?.Username);
                }
                else
                {
                    _logger.LogInformation("Kullanıcı giriş yapmamış");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Sayfayı yüklerken bir hata oluştu");
                StatusMessage = "Sayfa yüklenirken bir hata oluştu. Lütfen daha sonra tekrar deneyiniz.";
            }
        }

        // Demo oturumu açma (gerçek uygulamada login sayfası olmalı)
        public async Task<IActionResult> OnPostLoginDemoAsync()
        {
            _logger.LogInformation("Demo kullanıcısı giriş denemesi başlatıldı");

            try
            {
                // Sabit demo kullanıcısını oluştur (veritabanı hatası olsa bile çalışacak)
                var demoUser = new User
                {
                    Id = 1, // Sabit ID kullanılıyor
                    Username = "demo_user",
                    Email = "demo@example.com",
                    PasswordHash = "demo_password",
                    ProfileImageUrl = "https://source.unsplash.com/random/100x100/?avatar",
                    RegisteredDate = DateTime.Now.AddMonths(-2)
                };

                _logger.LogInformation("Demo kullanıcısı oluşturuldu: {id}", demoUser.Id);

                // Session'a kullanıcı ID'sini kaydet
                HttpContext.Session.SetInt32("UserId", demoUser.Id);

                // Session kaydını doğrula
                var sessionUserId = HttpContext.Session.GetInt32("UserId");
                _logger.LogInformation("Session'a kaydedilen UserId: {id}", sessionUserId);

                if (sessionUserId == null)
                {
                    _logger.LogWarning("Session'a UserId kaydedilemedi!");
                    // Session'a kaydedilemezse cookie deneyelim
                    Response.Cookies.Append("UserId", demoUser.Id.ToString(), new CookieOptions
                    {
                        HttpOnly = true,
                        Expires = DateTimeOffset.Now.AddHours(1)
                    });
                    _logger.LogInformation("UserId cookie'ye kaydedildi");
                }

                // Model için kullanıcı bilgilerini ayarla
                CurrentUserId = demoUser.Id;
                CurrentUser = demoUser;
                StatusMessage = "Demo kullanıcısı olarak giriş yapıldı.";

                // Haberleri yenile
                try
                {
                    NewsList = await _newsService.GetAllNewsAsync();
                    _logger.LogInformation("Login sonrası {count} haber yüklendi", NewsList.Count);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Login sonrası haber verileri yüklenirken hata oluştu");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Demo kullanıcısı ile giriş yaparken bir hata oluştu: {message}", ex.Message);
                StatusMessage = "Giriş yapılırken bir hata oluştu. Lütfen daha sonra tekrar deneyiniz.";
            }

            return RedirectToPage();
        }

        // Haber beğenme işlemi
        public async Task<IActionResult> OnPostLikeAsync(int newsId)
        {
            // Kullanıcı giriş yapmış mı kontrol et
            byte[]? userIdBytes = null;
            if (!HttpContext.Session.TryGetValue("UserId", out userIdBytes) || userIdBytes == null)
            {
                StatusMessage = "Haber beğenmek için giriş yapmalısınız.";
                return RedirectToPage();
            }

            var userId = BitConverter.ToInt32(userIdBytes, 0);

            try
            {
                // Haberi beğen
                var result = await _newsService.LikeNewsAsync(newsId, userId);

                if (!result)
                {
                    StatusMessage = "Bu haberi zaten beğendiniz veya işlem sırasında bir hata oluştu.";
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Haber beğenirken bir hata oluştu");
                StatusMessage = "İşlem sırasında bir hata oluştu. Lütfen daha sonra tekrar deneyiniz.";
            }

            return RedirectToPage();
        }

        // Haber yorum yapma işlemi
        public async Task<IActionResult> OnPostCommentAsync(int newsId, string commentContent)
        {
            // Kullanıcı giriş yapmış mı kontrol et
            byte[]? userIdBytes = null;
            if (!HttpContext.Session.TryGetValue("UserId", out userIdBytes) || userIdBytes == null)
            {
                StatusMessage = "Yorum yapmak için giriş yapmalısınız.";
                return RedirectToPage();
            }

            if (string.IsNullOrWhiteSpace(commentContent))
            {
                StatusMessage = "Yorum içeriği boş olamaz.";
                return RedirectToPage();
            }

            var userId = BitConverter.ToInt32(userIdBytes, 0);

            try
            {
                // Yorum ekle
                var comment = await _newsService.AddCommentAsync(newsId, userId, commentContent);

                if (comment == null)
                {
                    StatusMessage = "Yorum eklenirken bir hata oluştu.";
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Yorum eklerken bir hata oluştu");
                StatusMessage = "İşlem sırasında bir hata oluştu. Lütfen daha sonra tekrar deneyiniz.";
            }

            return RedirectToPage();
        }

        // Oturumu kapatma
        public IActionResult OnPostLogoutAsync()
        {
            HttpContext.Session.Clear();
            StatusMessage = "Oturum kapatıldı.";

            // Anasayfayı yeniden yükleyecek şekilde yönlendir
            return RedirectToPage();
        }

        // Haberi favorilere ekle
        public async Task<IActionResult> OnPostAddToFavoritesAsync(int newsId)
        {
            // Kullanıcı giriş yapmış mı kontrol et
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null)
            {
                StatusMessage = "Favorilere eklemek için giriş yapmalısınız.";
                return RedirectToPage("/Login");
            }

            try
            {
                // Haberi favorilere ekle
                var result = await _userService.AddToFavoritesAsync(userId.Value, newsId);

                if (result)
                {
                    StatusMessage = "Haber favorilerinize eklendi.";
                }
                else
                {
                    StatusMessage = "Bu haber zaten favorilerinizde veya işlem sırasında bir hata oluştu.";
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Haber favorilere eklenirken bir hata oluştu");
                StatusMessage = "İşlem sırasında bir hata oluştu. Lütfen daha sonra tekrar deneyiniz.";
            }

            return RedirectToPage();
        }
    }
}