using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using sosyalmedya2.Models;
using sosyalmedya2.Services;

namespace sosyalmedya2.Pages
{
    public class FavoritesModel : PageModel
    {
        private readonly ILogger<FavoritesModel> _logger;
        private readonly UserService _userService;

        public List<News> NewsList { get; set; } = new List<News>();
        public string StatusMessage { get; set; } = string.Empty;

        public FavoritesModel(ILogger<FavoritesModel> logger, UserService userService)
        {
            _logger = logger;
            _userService = userService;
        }

        public async Task<IActionResult> OnGetAsync()
        {
            // Kullanıcı girişi kontrolü
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null)
            {
                _logger.LogInformation("Giriş yapmamış kullanıcı favoriler sayfasına erişmeye çalıştı");
                return RedirectToPage("/Login");
            }

            try
            {
                // Kullanıcının favorilerini getir
                NewsList = await _userService.GetUserFavoritesAsync(userId.Value);
                _logger.LogInformation("Kullanıcı ID {userId} için {count} favori haber yüklendi", userId, NewsList.Count);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Favoriler yüklenirken hata oluştu");
                StatusMessage = "Favorileriniz yüklenirken bir hata oluştu. Lütfen daha sonra tekrar deneyiniz.";
            }

            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int newsId)
        {
            // Kullanıcı girişi kontrolü
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null)
            {
                return RedirectToPage("/Login");
            }

            try
            {
                // Haberi favorilerden kaldır
                var result = await _userService.RemoveFromFavoritesAsync(userId.Value, newsId);
                if (result)
                {
                    _logger.LogInformation("Kullanıcı ID {userId} için haber ID {newsId} favorilerden kaldırıldı", userId, newsId);
                    StatusMessage = "Haber favorilerinizden kaldırıldı.";
                }
                else
                {
                    _logger.LogWarning("Kullanıcı ID {userId} için haber ID {newsId} favorilerden kaldırılamadı", userId, newsId);
                    StatusMessage = "Haber favorilerinizden kaldırılamadı.";
                }

                // Güncel favoriler listesini yükle
                NewsList = await _userService.GetUserFavoritesAsync(userId.Value);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Haber favorilerden kaldırılırken hata oluştu");
                StatusMessage = "İşlem sırasında bir hata oluştu. Lütfen daha sonra tekrar deneyiniz.";
            }

            return Page();
        }
    }
}