using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using sosyalmedya2.Models;
using sosyalmedya2.Services;
using System.ComponentModel.DataAnnotations;

namespace sosyalmedya2.Pages
{
    public class RegisterModel : PageModel
    {
        private readonly ILogger<RegisterModel> _logger;
        private readonly UserService _userService;

        [BindProperty]
        public string Username { get; set; } = string.Empty;

        [BindProperty]
        [EmailAddress]
        public string Email { get; set; } = string.Empty;

        [BindProperty]
        [DataType(DataType.Password)]
        public string Password { get; set; } = string.Empty;

        [BindProperty]
        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "Şifreler eşleşmiyor.")]
        public string ConfirmPassword { get; set; } = string.Empty;

        public string StatusMessage { get; set; } = string.Empty;
        public bool IsError { get; set; } = false;

        public RegisterModel(ILogger<RegisterModel> logger, UserService userService)
        {
            _logger = logger;
            _userService = userService;
        }

        public void OnGet()
        {
            // Zaten giriş yapılmışsa ana sayfaya yönlendir
            if (HttpContext.Session.GetInt32("UserId") != null)
            {
                Response.Redirect("/home");
            }
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (string.IsNullOrEmpty(Username) || string.IsNullOrEmpty(Email) ||
                string.IsNullOrEmpty(Password) || string.IsNullOrEmpty(ConfirmPassword))
            {
                StatusMessage = "Tüm alanları doldurunuz.";
                IsError = true;
                return Page();
            }

            if (Password != ConfirmPassword)
            {
                StatusMessage = "Şifreler eşleşmiyor.";
                IsError = true;
                return Page();
            }

            var user = await _userService.RegisterAsync(Username, Email, Password);
            if (user != null)
            {
                _logger.LogInformation("Yeni kullanıcı kaydedildi: {username}", Username);

                // Session'a kullanıcı ID'sini kaydet ve otomatik giriş yap
                HttpContext.Session.SetInt32("UserId", user.Id);

                // Ana sayfaya yönlendir
                return RedirectToPage("/Home");
            }
            else
            {
                _logger.LogWarning("Kullanıcı kaydedilemedi: {username}", Username);
                StatusMessage = "Bu kullanıcı adı veya e-posta ile kayıt yapılamaz. Lütfen farklı bilgiler deneyiniz.";
                IsError = true;
                return Page();
            }
        }
    }
}