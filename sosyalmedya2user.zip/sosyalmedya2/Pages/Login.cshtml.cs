using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using sosyalmedya2.Models;
using sosyalmedya2.Services;

namespace sosyalmedya2.Pages
{
    public class LoginModel : PageModel
    {
        private readonly ILogger<LoginModel> _logger;
        private readonly UserService _userService;

        [BindProperty]
        public string Username { get; set; } = string.Empty;

        [BindProperty]
        public string Password { get; set; } = string.Empty;

        public string StatusMessage { get; set; } = string.Empty;
        public bool IsError { get; set; } = false;

        public LoginModel(ILogger<LoginModel> logger, UserService userService)
        {
            _logger = logger;
            _userService = userService;
        }

        public void OnGet()
        {
            // Zaten giriş yapılmışsa ana sayfaya yönlendir
            if (HttpContext.Session.GetInt32("UserId") != null)
            {
                Response.Redirect("/home");
            }
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (string.IsNullOrEmpty(Username) || string.IsNullOrEmpty(Password))
            {
                StatusMessage = "Kullanıcı adı ve şifre boş olamaz.";
                IsError = true;
                return Page();
            }

            var user = await _userService.LoginAsync(Username, Password);
            if (user != null)
            {
                _logger.LogInformation("Kullanıcı başarıyla giriş yaptı: {username}", Username);

                // Session'a kullanıcı ID'sini kaydet
                HttpContext.Session.SetInt32("UserId", user.Id);

                // Ana sayfaya yönlendir
                return RedirectToPage("/Home");
            }
            else
            {
                _logger.LogWarning("Başarısız giriş denemesi: {username}", Username);
                StatusMessage = "Kullanıcı adı veya şifre yanlış.";
                IsError = true;
                return Page();
            }
        }
    }
}