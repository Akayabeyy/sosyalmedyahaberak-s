using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace sosyalmedya2.Models
{
    public class Favorite
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int UserId { get; set; }

        [Required]
        public int NewsId { get; set; }

        public DateTime CreatedDate { get; set; } = DateTime.Now;

        // İlişkiler
        [ForeignKey("UserId")]
        public virtual User User { get; set; }

        [ForeignKey("NewsId")]
        public virtual News News { get; set; }
    }
}