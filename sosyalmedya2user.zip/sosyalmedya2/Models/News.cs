using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace sosyalmedya2.Models
{
    public class News
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(200)]
        public string Title { get; set; } = string.Empty;

        [Required]
        public string Content { get; set; } = string.Empty;

        [Required]
        public string ImageUrl { get; set; } = string.Empty;

        [Required]
        public DateTime PublishedDate { get; set; } = DateTime.Now;

        [Required]
        public string AuthorName { get; set; } = string.Empty;

        [Required]
        public string AuthorImageUrl { get; set; } = string.Empty;

        public int LikeCount { get; set; } = 0;

        public int CommentCount { get; set; } = 0;

        public int FavoriteCount { get; set; } = 0;

        // İlişkiler
        public virtual ICollection<Comment> Comments { get; set; } = new List<Comment>();
        public virtual ICollection<Like> Likes { get; set; } = new List<Like>();
        public virtual ICollection<Favorite> Favorites { get; set; } = new List<Favorite>();
    }
}