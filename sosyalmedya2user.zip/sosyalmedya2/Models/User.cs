using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace sosyalmedya2.Models
{
    public class User
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(50)]
        public string Username { get; set; } = string.Empty;

        [Required]
        [EmailAddress]
        [StringLength(100)]
        public string Email { get; set; } = string.Empty;

        [Required]
        [StringLength(100)]
        public string PasswordHash { get; set; } = string.Empty;

        public string? ProfileImageUrl { get; set; }

        public DateTime RegisteredDate { get; set; } = DateTime.Now;

        // İlişkiler
        public virtual ICollection<Comment> Comments { get; set; } = new List<Comment>();
        public virtual ICollection<Like> Likes { get; set; } = new List<Like>();
        public virtual ICollection<Favorite> Favorites { get; set; } = new List<Favorite>();
    }
}