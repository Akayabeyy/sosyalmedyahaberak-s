using Microsoft.AspNetCore.Mvc;
using sosyalmedya2.Models;
using sosyalmedya2.Services;
using sosyalmedya2.Data;
using System;
using Microsoft.Extensions.Logging;

namespace sosyalmedya2.Components
{
    public class UserLoginViewComponent : ViewComponent
    {
        private readonly UserService _userService;
        private readonly UserDbContext _userDbContext;
        private readonly ILogger<UserLoginViewComponent> _logger;

        public UserLoginViewComponent(UserService userService, UserDbContext userDbContext,
                                     ILogger<UserLoginViewComponent> logger)
        {
            _userService = userService;
            _userDbContext = userDbContext;
            _logger = logger;
        }

        public async Task<IViewComponentResult> InvokeAsync()
        {
            User? currentUser = null;

            try
            {
                // Kullanıcı ID'sini önce session'dan almayı dene
                int? userId = HttpContext.Session.GetInt32("UserId");

                // Session'da yoksa cookie'den kontrol et
                if (userId == null)
                {
                    string? userIdCookie = Request.Cookies["UserId"];
                    if (!string.IsNullOrEmpty(userIdCookie) && int.TryParse(userIdCookie, out int cookieUserId))
                    {
                        userId = cookieUserId;
                        _logger.LogInformation("UserLoginViewComponent: UserId={id} cookie'den okundu", userId);
                    }
                }
                else
                {
                    _logger.LogInformation("UserLoginViewComponent: UserId={id} session'dan okundu", userId);
                }

                // Kullanıcı ID'si mevcutsa kullanıcıyı bul
                if (userId.HasValue)
                {
                    try
                    {
                        // Önce servis üzerinden dene
                        currentUser = await _userService.GetUserByIdAsync(userId.Value);

                        // Bulunamazsa manuel demo kullanıcısı oluştur
                        if (currentUser == null && userId.Value == 1) // Demo kullanıcısı ID'si 1 olarak belirlenmiş
                        {
                            _logger.LogInformation("UserLoginViewComponent: Demo kullanıcısı oluşturuluyor");
                            currentUser = new User
                            {
                                Id = 1,
                                Username = "demo_user",
                                Email = "demo@example.com"
                            };
                        }

                        if (currentUser != null)
                        {
                            _logger.LogInformation("UserLoginViewComponent: {username} kullanıcısı bulundu", currentUser.Username);
                        }
                        else
                        {
                            _logger.LogWarning("UserLoginViewComponent: UserId={id} ile kullanıcı bulunamadı", userId);
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "UserLoginViewComponent: Kullanıcı bilgisini alırken veritabanı hatası oluştu");

                        // Hata durumunda demo kullanıcısı oluştur (UI'ın çalışmaya devam etmesi için)
                        if (userId.Value == 1)
                        {
                            currentUser = new User { Id = 1, Username = "demo_user", Email = "demo@example.com" };
                            _logger.LogInformation("UserLoginViewComponent: Veritabanı hatası sonrası manuel demo kullanıcısı oluşturuldu");
                        }
                    }
                }
                else
                {
                    _logger.LogInformation("UserLoginViewComponent: Kullanıcı giriş yapmamış");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "UserLoginViewComponent: Kullanıcı bilgisi alınırken genel hata oluştu");
            }

            return View(currentUser);
        }
    }
}