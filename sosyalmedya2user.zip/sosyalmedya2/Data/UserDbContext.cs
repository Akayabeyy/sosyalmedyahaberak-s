using Microsoft.EntityFrameworkCore;
using sosyalmedya2.Models;

namespace sosyalmedya2.Data
{
    public class UserDbContext : DbContext
    {
        public UserDbContext(DbContextOptions<UserDbContext> options) : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Favorite> Favorites { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // İlişkileri yapılandır
            modelBuilder.Entity<User>()
                .HasMany(u => u.Comments)
                .WithOne(c => c.User)
                .HasForeignKey(c => c.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<User>()
                .HasMany(u => u.Likes)
                .WithOne(l => l.User)
                .HasForeignKey(l => l.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<User>()
                .HasMany(u => u.Favorites)
                .WithOne(f => f.User)
                .HasForeignKey(f => f.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            // Örnek kullanıcı verisi ekle
            modelBuilder.Entity<User>().HasData(
                new User
                {
                    Id = 1,
                    Username = "demo_user",
                    Email = "demo@example.com",
                    PasswordHash = "AQAAAAIAAYagAAAAELbVjJZNd1Qo8RuCXRqXVT0v99BTdC58qBKiUrIW9qiQ6fzdicK30wDHAJjW3pJPPw==", // "Password123!"
                    ProfileImageUrl = "https://source.unsplash.com/random/100x100/?avatar",
                    RegisteredDate = DateTime.Now.AddMonths(-2)
                }
            );
        }
    }
}