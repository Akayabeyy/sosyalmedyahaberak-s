using Microsoft.EntityFrameworkCore;
using sosyalmedya2.Models;

namespace sosyalmedya2.Data
{
    public class NewsDbContext : DbContext
    {
        public NewsDbContext(DbContextOptions<NewsDbContext> options) : base(options)
        {
        }

        public DbSet<News> News { get; set; }
        public DbSet<Comment> Comments { get; set; }
        public DbSet<Like> Likes { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // İlişkileri yapılandır
            modelBuilder.Entity<News>()
                .HasMany(n => n.Comments)
                .WithOne(c => c.News)
                .HasForeignKey(c => c.NewsId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<News>()
                .HasMany(n => n.Likes)
                .WithOne(l => l.News)
                .HasForeignKey(l => l.NewsId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<News>()
                .HasMany(n => n.Favorites)
                .WithOne(f => f.News)
                .HasForeignKey(f => f.NewsId)
                .OnDelete(DeleteBehavior.Cascade);

            // Örnek haber verilerini ekle
            modelBuilder.Entity<News>().HasData(
                new News
                {
                    Id = 1,
                    Title = "New AI Breakthrough Promises to Revolutionize Healthcare",
                    Content = "A groundbreaking artificial intelligence system has demonstrated the ability to diagnose rare diseases with accuracy that surpasses experienced medical specialists. The system, developed by researchers at Stanford University, analyzes patient symptoms and medical history to provide diagnostic recommendations.",
                    ImageUrl = "https://source.unsplash.com/random/800x600/?technology",
                    PublishedDate = DateTime.Now.AddHours(-2),
                    AuthorName = "Dr. Emma Wilson",
                    AuthorImageUrl = "https://source.unsplash.com/random/100x100/?portrait1",
                    LikeCount = 247,
                    CommentCount = 42
                },
                new News
                {
                    Id = 2,
                    Title = "Global Climate Summit Ends with Historic Agreement",
                    Content = "World leaders have reached a landmark agreement at the climate summit, pledging to reduce carbon emissions by 50% by 2030. The agreement, which includes all major economies, represents the most ambitious climate action to date and sets a clear path toward limiting global warming to 1.5 degrees Celsius.",
                    ImageUrl = "https://source.unsplash.com/random/800x600/?climate",
                    PublishedDate = DateTime.Now.AddDays(-1),
                    AuthorName = "Michael Chen",
                    AuthorImageUrl = "https://source.unsplash.com/random/100x100/?portrait2",
                    LikeCount = 583,
                    CommentCount = 98
                },
                new News
                {
                    Id = 3,
                    Title = "Astronomers Discover Potentially Habitable Exoplanet",
                    Content = "A team of astronomers has identified a rocky exoplanet orbiting within the habitable zone of a nearby star. The planet, designated Kepler-442c, is approximately 1.3 times the size of Earth and shows evidence of a stable atmosphere. Preliminary spectroscopic analysis suggests the presence of water vapor.",
                    ImageUrl = "https://source.unsplash.com/random/800x600/?space",
                    PublishedDate = DateTime.Now.AddDays(-3),
                    AuthorName = "Prof. Sarah Johnson",
                    AuthorImageUrl = "https://source.unsplash.com/random/100x100/?portrait3",
                    LikeCount = 729,
                    CommentCount = 156
                },
                new News
                {
                    Id = 4,
                    Title = "Tech Startup Secures Record $2 Billion in Funding",
                    Content = "A quantum computing startup has secured $2 billion in Series C funding, marking the largest investment round for a quantum technology company to date. The startup, founded by former researchers from MIT, plans to use the funding to accelerate the development of its scalable quantum processors.",
                    ImageUrl = "https://source.unsplash.com/random/800x600/?business",
                    PublishedDate = DateTime.Now.AddDays(-5),
                    AuthorName = "Jessica Taylor",
                    AuthorImageUrl = "https://source.unsplash.com/random/100x100/?portrait4",
                    LikeCount = 412,
                    CommentCount = 73
                }
            );
        }
    }
}