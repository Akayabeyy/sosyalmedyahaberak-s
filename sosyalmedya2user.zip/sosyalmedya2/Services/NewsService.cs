using Microsoft.EntityFrameworkCore;
using sosyalmedya2.Data;
using sosyalmedya2.Models;
using Microsoft.Extensions.Logging;
using System.Diagnostics;

namespace sosyalmedya2.Services
{
    public class NewsService
    {
        private readonly NewsDbContext _newsDbContext;
        private readonly UserDbContext _userDbContext;
        private readonly ILogger<NewsService> _logger;

        public NewsService(NewsDbContext newsDbContext, UserDbContext userDbContext, ILogger<NewsService> logger)
        {
            _newsDbContext = newsDbContext;
            _userDbContext = userDbContext;
            _logger = logger;
        }

        // Tüm haberleri getir
        public async Task<List<News>> GetAllNewsAsync()
        {
            _logger.LogInformation("GetAllNewsAsync - Tüm haberleri almaya çalışıyor...");
            var stopwatch = Stopwatch.StartNew();

            try
            {
                // Veritabanı bağlantısını kontrol et
                var canConnect = await _newsDbContext.Database.CanConnectAsync();
                _logger.LogInformation("Veritabanına bağlanılabilir mi? {result}", canConnect);

                if (!canConnect)
                {
                    _logger.LogError("Veritabanına bağlanılamıyor! Yedek haber listesi döndürülüyor.");
                    return CreateFallbackNews("Veritabanı bağlantı hatası");
                }

                // Doğrudan haberleri getir - Daha basit ve güvenilir
                List<News> newsFromDb = new List<News>();
                try
                {
                    _logger.LogInformation("Haberleri veritabanından getirme işlemi başlatılıyor...");

                    // En basit ve en güvenilir şekilde haberleri almak için direkt sorgu kullan
                    newsFromDb = await _newsDbContext.News
                        .AsNoTracking() // Performans için
                        .OrderByDescending(n => n.PublishedDate)
                        .ToListAsync();

                    _logger.LogInformation("Veritabanından {count} haber başarıyla getirildi.", newsFromDb.Count);

                    // Her bir haberin ID ve başlığını günlüğe kaydet
                    foreach (var news in newsFromDb)
                    {
                        _logger.LogInformation("Haber yüklendi: ID={id}, Başlık={title}", news.Id, news.Title);
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Haberleri getirirken hata oluştu!");
                    _logger.LogInformation("Hata türü: {exType}, Hata mesajı: {message}",
                        ex.GetType().Name, ex.Message);

                    if (ex.InnerException != null)
                    {
                        _logger.LogInformation("İç hata: {message}", ex.InnerException.Message);
                    }
                }

                // Hiç haber yoksa, örnek haber eklemeyi dene
                if (newsFromDb.Count == 0)
                {
                    _logger.LogWarning("Veritabanında hiç haber bulunamadı, örnek haber eklenecek");

                    try
                    {
                        // Tablonun var olup olmadığını kontrol et (SQLite'a uygun)
                        bool tableExists = false;
                        try
                        {
                            var result = await _newsDbContext.Database
                                .ExecuteSqlRawAsync("SELECT count(*) FROM sqlite_master WHERE type='table' AND name='News'");
                            tableExists = result > 0;
                            _logger.LogInformation("News tablosu var mı: {exists}", tableExists);
                        }
                        catch (Exception ex)
                        {
                            _logger.LogError(ex, "Tablo kontrolü başarısız oldu");
                        }

                        if (!tableExists)
                        {
                            _logger.LogWarning("News tablosu bulunamadı, EnsureCreated çağrılıyor...");
                            await _newsDbContext.Database.EnsureCreatedAsync();
                        }

                        // Örnek haber ekle
                        var testNews = new News
                        {
                            Title = "Günün Önemli Haberi",
                            Content = "Bu haber, veritabanı boş olduğu için otomatik olarak eklendi. Gerçek haberler yakında burada olacak.",
                            ImageUrl = "https://source.unsplash.com/random/800x600/?news",
                            PublishedDate = DateTime.Now,
                            AuthorName = "Sistem",
                            AuthorImageUrl = "https://source.unsplash.com/random/100x100/?system",
                            LikeCount = 5,
                            CommentCount = 2
                        };

                        _newsDbContext.News.Add(testNews);
                        await _newsDbContext.SaveChangesAsync();
                        _logger.LogInformation("Örnek haber başarıyla eklendi. ID: {id}", testNews.Id);

                        // Eklenen haberi listeye ekle
                        newsFromDb.Add(testNews);

                        // Birkaç haber daha ekleyelim
                        var additionalNews = new List<News>
                        {
                            new News
                            {
                                Title = "Teknoloji Dünyasında Büyük Gelişme",
                                Content = "Son teknolojik gelişmelerle birlikte, yapay zeka alanında önemli ilerlemeler kaydedildi.",
                                ImageUrl = "https://source.unsplash.com/random/800x600/?technology",
                                PublishedDate = DateTime.Now.AddHours(-3),
                                AuthorName = "Tech Editor",
                                AuthorImageUrl = "https://source.unsplash.com/random/100x100/?tech",
                                LikeCount = 42,
                                CommentCount = 8
                            },
                            new News
                            {
                                Title = "Spor Dünyasından Son Haberler",
                                Content = "Bu hafta sonu gerçekleşen müsabakalarda beklenmedik sonuçlar alındı ve birçok rekor kırıldı.",
                                ImageUrl = "https://source.unsplash.com/random/800x600/?sports",
                                PublishedDate = DateTime.Now.AddHours(-5),
                                AuthorName = "Spor Muhabiri",
                                AuthorImageUrl = "https://source.unsplash.com/random/100x100/?sports",
                                LikeCount = 87,
                                CommentCount = 15
                            }
                        };

                        _newsDbContext.News.AddRange(additionalNews);
                        await _newsDbContext.SaveChangesAsync();
                        _logger.LogInformation("Ek haberler başarıyla eklendi.");

                        // Eklenen haberleri listeye ekle
                        newsFromDb.AddRange(additionalNews);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Örnek haber eklenirken hata oluştu: {message}", ex.Message);
                        return CreateFallbackNews("Veri ekleme hatası");
                    }
                }

                // Son kontrol
                if (newsFromDb.Count == 0)
                {
                    _logger.LogWarning("Tüm denemelere rağmen haber bulunamadı!");
                    return CreateFallbackNews("Veri bulunamadı");
                }

                return newsFromDb;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "GetAllNewsAsync metodunda genel bir hata oluştu: {message}", ex.Message);
                return CreateFallbackNews("Genel hata");
            }
            finally
            {
                stopwatch.Stop();
                _logger.LogInformation("GetAllNewsAsync metodu tamamlandı. Toplam süre: {ms}ms", stopwatch.ElapsedMilliseconds);
            }
        }

        // Yedek haber oluşturma yardımcı metodu
        private List<News> CreateFallbackNews(string errorType)
        {
            return new List<News>
            {
                new News
                {
                    Id = 8888,
                    Title = $"Veritabanı Bağlantı Sorunu ({errorType})",
                    Content = $"Şu anda haberler veritabanından çekilemiyor: {errorType}. Bu bir geçici bir durumdur ve en kısa sürede düzeltilecektir.",
                    ImageUrl = "https://source.unsplash.com/random/800x600/?error",
                    PublishedDate = DateTime.Now,
                    AuthorName = "Sistem",
                    AuthorImageUrl = "https://source.unsplash.com/random/100x100/?system",
                    LikeCount = 0,
                    CommentCount = 0
                },
                new News
                {
                    Id = 9999,
                    Title = "Günün Önemli Gelişmeleri",
                    Content = "Bu içerik, veritabanına erişim sorunu yaşandığında gösterilmek üzere hazırlanmıştır. Gerçek haberler yakında burada olacak.",
                    ImageUrl = "https://source.unsplash.com/random/800x600/?important",
                    PublishedDate = DateTime.Now.AddHours(-1),
                    AuthorName = "Sistem Yöneticisi",
                    AuthorImageUrl = "https://source.unsplash.com/random/100x100/?admin",
                    LikeCount = 5,
                    CommentCount = 2
                }
            };
        }

        // ID'ye göre haber getir
        public async Task<News?> GetNewsByIdAsync(int id)
        {
            return await _newsDbContext.News
                .Include(n => n.Comments)
                .ThenInclude(c => c.User)
                .Include(n => n.Likes)
                .FirstOrDefaultAsync(n => n.Id == id);
        }

        // Haber beğen
        public async Task<bool> LikeNewsAsync(int newsId, int userId)
        {
            // Kullanıcının daha önce beğenip beğenmediğini kontrol et
            var existingLike = await _newsDbContext.Likes
                .FirstOrDefaultAsync(l => l.NewsId == newsId && l.UserId == userId);

            if (existingLike != null)
            {
                return false; // Zaten beğenilmiş
            }

            var news = await _newsDbContext.News.FindAsync(newsId);
            if (news == null)
            {
                return false; // Haber bulunamadı
            }

            var like = new Like
            {
                NewsId = newsId,
                UserId = userId,
                CreatedDate = DateTime.Now
            };

            await _newsDbContext.Likes.AddAsync(like);

            // Beğeni sayısını artır
            news.LikeCount += 1;

            await _newsDbContext.SaveChangesAsync();
            return true;
        }

        // Haber yorumu ekle
        public async Task<Comment?> AddCommentAsync(int newsId, int userId, string content)
        {
            var news = await _newsDbContext.News.FindAsync(newsId);
            if (news == null)
            {
                return null; // Haber bulunamadı
            }

            var comment = new Comment
            {
                NewsId = newsId,
                UserId = userId,
                Content = content,
                CreatedDate = DateTime.Now
            };

            await _newsDbContext.Comments.AddAsync(comment);

            // Yorum sayısını artır
            news.CommentCount += 1;

            await _newsDbContext.SaveChangesAsync();

            // Kullanıcı bilgisini dahil et
            comment.User = await _userDbContext.Users.FindAsync(userId);

            return comment;
        }

        // Kullanıcının bir haberi beğenip beğenmediğini kontrol et
        public async Task<bool> HasUserLikedNewsAsync(int newsId, int userId)
        {
            return await _newsDbContext.Likes
                .AnyAsync(l => l.NewsId == newsId && l.UserId == userId);
        }

        // Habere ait yorumları getir
        public async Task<List<Comment>> GetNewsCommentsAsync(int newsId)
        {
            return await _newsDbContext.Comments
                .Include(c => c.User)
                .Where(c => c.NewsId == newsId)
                .OrderByDescending(c => c.CreatedDate)
                .ToListAsync();
        }
    }
}