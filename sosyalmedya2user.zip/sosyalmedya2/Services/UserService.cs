using Microsoft.EntityFrameworkCore;
using sosyalmedya2.Data;
using sosyalmedya2.Models;
using System.Security.Cryptography;
using System.Text;

namespace sosyalmedya2.Services
{
    public class UserService
    {
        private readonly UserDbContext _userDbContext;
        private readonly NewsDbContext _newsDbContext;
        private readonly ILogger<UserService> _logger;

        public UserService(UserDbContext userDbContext, NewsDbContext newsDbContext, ILogger<UserService> logger)
        {
            _userDbContext = userDbContext;
            _newsDbContext = newsDbContext;
            _logger = logger;
        }

        // Kullanıcı girişi
        public async Task<User?> LoginAsync(string username, string password)
        {
            _logger.LogInformation("Kullanıcı girişi: {username}", username);

            // Kullanıcıyı username veya email ile ara
            var user = await _userDbContext.Users
                .FirstOrDefaultAsync(u => u.Username == username || u.Email == username);

            if (user == null)
            {
                _logger.LogWarning("Kullanıcı bulunamadı: {username}", username);
                return null; // Kullanıcı bulunamadı
            }

            // Geliştirme ortamında basit şifre kontrolü - gerçek uygulamada hash kullanılmalıdır
            if (user.PasswordHash == password)
            {
                _logger.LogInformation("Kullanıcı başarıyla giriş yaptı: {username}", username);
                return user;
            }

            _logger.LogWarning("Hatalı şifre girişi: {username}", username);
            return null; // Şifre yanlış
        }

        // Hash password oluşturma (gerçek uygulamada daha güçlü bir yöntem kullanılmalıdır)
        public string HashPassword(string password)
        {
            // Bu örnek için basit bir şekilde şifreyi doğrudan kullanıyoruz
            // Gerçek uygulamada güçlü bir hash algoritması kullanılmalıdır
            return password;
        }

        // Kullanıcı bilgisini ID'ye göre getir
        public async Task<User?> GetUserByIdAsync(int id)
        {
            return await _userDbContext.Users
                .Include(u => u.Favorites)
                .ThenInclude(f => f.News)
                .FirstOrDefaultAsync(u => u.Id == id);
        }

        // Kullanıcının favorilerini getir
        public async Task<List<News>> GetUserFavoritesAsync(int userId)
        {
            return await _userDbContext.Favorites
                .Where(f => f.UserId == userId)
                .Include(f => f.News)
                .Select(f => f.News)
                .ToListAsync();
        }

        // Haberi favorilere ekle
        public async Task<bool> AddToFavoritesAsync(int userId, int newsId)
        {
            // Zaten favorilerde mi kontrol et
            var existingFavorite = await _userDbContext.Favorites
                .FirstOrDefaultAsync(f => f.UserId == userId && f.NewsId == newsId);

            if (existingFavorite != null)
            {
                return false; // Zaten favorilerde
            }

            // Haberin var olduğunu doğrula
            var news = await _newsDbContext.News.FindAsync(newsId);
            if (news == null)
            {
                return false; // Haber bulunamadı
            }

            // Favorilere ekle
            var favorite = new Favorite
            {
                UserId = userId,
                NewsId = newsId,
                CreatedDate = DateTime.Now
            };

            await _userDbContext.Favorites.AddAsync(favorite);

            // Favori sayısını artır
            news.FavoriteCount += 1;
            _newsDbContext.News.Update(news);

            await _userDbContext.SaveChangesAsync();
            await _newsDbContext.SaveChangesAsync();

            return true;
        }

        // Favorilerden kaldır
        public async Task<bool> RemoveFromFavoritesAsync(int userId, int newsId)
        {
            var favorite = await _userDbContext.Favorites
                .FirstOrDefaultAsync(f => f.UserId == userId && f.NewsId == newsId);

            if (favorite == null)
            {
                return false; // Favorilerde bulunamadı
            }

            // Favoriden kaldır
            _userDbContext.Favorites.Remove(favorite);

            // Favori sayısını azalt
            var news = await _newsDbContext.News.FindAsync(newsId);
            if (news != null && news.FavoriteCount > 0)
            {
                news.FavoriteCount -= 1;
                _newsDbContext.News.Update(news);
            }

            await _userDbContext.SaveChangesAsync();
            await _newsDbContext.SaveChangesAsync();

            return true;
        }

        // Kullanıcı hesabı oluşturma
        public async Task<User?> RegisterAsync(string username, string email, string password)
        {
            // Kullanıcı adı veya e-posta kullanımda mı kontrol et
            var existingUser = await _userDbContext.Users
                .FirstOrDefaultAsync(u => u.Username == username || u.Email == email);

            if (existingUser != null)
            {
                return null; // Kullanıcı adı veya e-posta zaten kullanımda
            }

            // Yeni kullanıcı oluştur
            var user = new User
            {
                Username = username,
                Email = email,
                PasswordHash = password, // Gerçek uygulamada hash kullanılmalıdır
                ProfileImageUrl = "https://source.unsplash.com/random/100x100/?person",
                RegisteredDate = DateTime.Now
            };

            await _userDbContext.Users.AddAsync(user);
            await _userDbContext.SaveChangesAsync();

            return user;
        }
    }
}