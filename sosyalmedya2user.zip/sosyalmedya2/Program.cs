using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using sosyalmedya2.Data;
using sosyalmedya2.Services;
using Microsoft.AspNetCore.Mvc;
using sosyalmedya2.Models;
using System.Diagnostics;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorPages(options =>
{
    options.Conventions.ConfigureFilter(new IgnoreAntiforgeryTokenAttribute());
});

// Add session support
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromHours(1); // Daha uzun oturum süresi
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
    options.Cookie.SecurePolicy = CookieSecurePolicy.Always; // HTTPS için
    options.Cookie.SameSite = SameSiteMode.Strict; // Güvenlik için
});

// Logging düzeyini geliştir
builder.Logging.ClearProviders();
builder.Logging.AddConsole();
builder.Logging.AddDebug();
builder.Logging.SetMinimumLevel(LogLevel.Information);

// SQLite veritabanı bağlantılarını ekle - yolları kesin olarak belirt
var contentRootPath = builder.Environment.ContentRootPath;
Console.WriteLine($"Content Root Path: {contentRootPath}");

// Veritabanı dosyalarını app_data klasörüne yerleştir (yoksa oluştur)
var appDataPath = Path.Combine(contentRootPath, "app_data");
if (!Directory.Exists(appDataPath))
{
    Directory.CreateDirectory(appDataPath);
    Console.WriteLine($"Created app_data directory: {appDataPath}");
}

var newsDbPath = Path.Combine(appDataPath, "haberler.db");
Console.WriteLine($"News DB Path: {newsDbPath}");
builder.Services.AddDbContext<NewsDbContext>(options =>
    options.UseSqlite($"Data Source={newsDbPath}"));

var userDbPath = Path.Combine(appDataPath, "user.db");
Console.WriteLine($"User DB Path: {userDbPath}");
builder.Services.AddDbContext<UserDbContext>(options =>
    options.UseSqlite($"Data Source={userDbPath}"));

// Servisleri ekle
builder.Services.AddScoped<NewsService>();
builder.Services.AddScoped<UserService>();

// Add HTTPS configuration with stronger settings
builder.Services.AddHttpsRedirection(options =>
{
    options.HttpsPort = 7141; // Port numarasını değiştirelim
    options.RedirectStatusCode = StatusCodes.Status307TemporaryRedirect;
});

var app = builder.Build();

// Veritabanı migration işlemlerini ve seed işlemlerini otomatik olarak uygula
using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    var logger = services.GetRequiredService<ILogger<Program>>();

    try
    {
        // Haberler veritabanını oluştur ve seed et
        logger.LogInformation("Haberler veritabanı oluşturuluyor...");
        var newsDbContext = services.GetRequiredService<NewsDbContext>();

        // Veritabanını oluştur (yalnızca yoksa)
        bool newsDbCreated = newsDbContext.Database.EnsureCreated();
        logger.LogInformation("Haberler veritabanı oluşturuldu mu: {result}", newsDbCreated);

        // Mevcut haber sayısını kontrol et
        int newsCount = 0;
        try
        {
            newsCount = newsDbContext.News.Count();
            logger.LogInformation("Veritabanında bulunan haber sayısı: {count}", newsCount);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Haber sayısı alınamadı");
        }

        // Eğer haber yoksa, manuel olarak ekle
        if (newsCount == 0)
        {
            logger.LogInformation("Haber bulunamadı, örnek haberler ekleniyor...");

            try
            {
                newsDbContext.News.Add(
                    new News
                    {
                        Title = "Test Haber - Elle Eklendi",
                        Content = "Bu haber, veritabanı sorununu tespit etmek için manuel olarak eklendi.",
                        ImageUrl = "https://source.unsplash.com/random/800x600/?test",
                        PublishedDate = DateTime.Now,
                        AuthorName = "Sistem Yöneticisi",
                        AuthorImageUrl = "https://source.unsplash.com/random/100x100/?admin",
                        LikeCount = 1,
                        CommentCount = 0
                    }
                );

                newsDbContext.SaveChanges();
                logger.LogInformation("Test haberi başarıyla eklendi. Yeni haber sayısı: {count}", newsDbContext.News.Count());
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Test haberi eklenirken hata oluştu");
            }

            // Sonra örnek haberleri ekle
            try
            {
                newsDbContext.News.AddRange(
                    new News
                    {
                        Title = "New AI Breakthrough Promises to Revolutionize Healthcare",
                        Content = "A groundbreaking artificial intelligence system has demonstrated the ability to diagnose rare diseases with accuracy that surpasses experienced medical specialists. The system, developed by researchers at Stanford University, analyzes patient symptoms and medical history to provide diagnostic recommendations.",
                        ImageUrl = "https://source.unsplash.com/random/800x600/?technology",
                        PublishedDate = DateTime.Now.AddHours(-2),
                        AuthorName = "Dr. Emma Wilson",
                        AuthorImageUrl = "https://source.unsplash.com/random/100x100/?portrait1",
                        LikeCount = 247,
                        CommentCount = 42
                    },
                    new News
                    {
                        Title = "Global Climate Summit Ends with Historic Agreement",
                        Content = "World leaders have reached a landmark agreement at the climate summit, pledging to reduce carbon emissions by 50% by 2030. The agreement, which includes all major economies, represents the most ambitious climate action to date and sets a clear path toward limiting global warming to 1.5 degrees Celsius.",
                        ImageUrl = "https://source.unsplash.com/random/800x600/?climate",
                        PublishedDate = DateTime.Now.AddDays(-1),
                        AuthorName = "Michael Chen",
                        AuthorImageUrl = "https://source.unsplash.com/random/100x100/?portrait2",
                        LikeCount = 583,
                        CommentCount = 98
                    },
                    new News
                    {
                        Title = "Yeni bir dönem başlıyor",
                        Content = "Türkiye'nin teknoloji alanında yaptığı atılımlar dünya genelinde dikkat çekiyor. Son yıllarda özellikle yazılım ve donanım alanında gerçekleştirilen yerli projeler, uluslararası arenada büyük ilgi görüyor.",
                        ImageUrl = "https://source.unsplash.com/random/800x600/?turkey",
                        PublishedDate = DateTime.Now.AddHours(-5),
                        AuthorName = "Ahmet Yılmaz",
                        AuthorImageUrl = "https://source.unsplash.com/random/100x100/?portrait5",
                        LikeCount = 329,
                        CommentCount = 57
                    }
                );
                newsDbContext.SaveChanges();
                logger.LogInformation("Örnek haberler başarıyla eklendi. Toplam haber sayısı: {count}", newsDbContext.News.Count());
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Örnek haberler eklenirken hata oluştu");
            }
        }

        // Kullanıcılar veritabanını oluştur ve seed et
        logger.LogInformation("Kullanıcılar veritabanı oluşturuluyor...");
        var userDbContext = services.GetRequiredService<UserDbContext>();

        // Veritabanını oluştur (yalnızca yoksa)
        bool userDbCreated = userDbContext.Database.EnsureCreated();
        logger.LogInformation("Kullanıcılar veritabanı oluşturuldu mu: {result}", userDbCreated);

        // Mevcut kullanıcı sayısını kontrol et
        int userCount = 0;
        try
        {
            userCount = userDbContext.Users.Count();
            logger.LogInformation("Kullanıcı sayısı: {count}", userCount);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Kullanıcı sayısı alınamadı");
        }

        // Eğer demo kullanıcısı yoksa, manuel olarak ekle
        if (userCount == 0 || !userDbContext.Users.Any(u => u.Email == "demo@example.com"))
        {
            logger.LogInformation("Demo kullanıcısı bulunamadı, ekleniyor...");
            try
            {
                userDbContext.Users.Add(
                    new User
                    {
                        Username = "demo_user",
                        Email = "demo@example.com",
                        PasswordHash = "demo_password",
                        ProfileImageUrl = "https://source.unsplash.com/random/100x100/?avatar",
                        RegisteredDate = DateTime.Now.AddMonths(-2)
                    }
                );
                userDbContext.SaveChanges();
                logger.LogInformation("Demo kullanıcısı başarıyla eklendi. ID: {id}",
                    userDbContext.Users.FirstOrDefault(u => u.Email == "demo@example.com")?.Id ?? 0);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Demo kullanıcısı eklenirken hata oluştu");
            }
        }
    }
    catch (Exception ex)
    {
        logger.LogError(ex, "Veritabanı oluşturulurken bir hata oluştu.");
    }
}

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
}
else
{
    app.UseDeveloperExceptionPage();
}

// Always use HSTS - The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
app.UseHsts();

// Enforce HTTPS redirection
app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseSession();
app.UseRouting();

app.UseAuthorization();

app.MapRazorPages();

// Add default route to /home
app.MapGet("/", context =>
{
    context.Response.Redirect("/home");
    return Task.CompletedTask;
});

app.Run();
